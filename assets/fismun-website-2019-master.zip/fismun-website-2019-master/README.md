# FISMUN WEBSITE
Website for Freedom International School Model United Nations 2019.
This website is completely static.
